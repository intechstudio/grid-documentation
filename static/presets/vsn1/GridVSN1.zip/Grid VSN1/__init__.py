from .LastTouchedControl import LastTouchedControl



def create_instance(c_instance):
    return LastTouchedControl(c_instance)


