from .Grid_VSN1 import Grid_VSN1



def create_instance(c_instance):
    return Grid_VSN1(c_instance)


