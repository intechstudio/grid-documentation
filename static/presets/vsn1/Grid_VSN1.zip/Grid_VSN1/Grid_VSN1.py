import Live
import time
from ableton.v2.control_surface import ControlSurface
from ableton.v2.control_surface.elements import EncoderElement, ButtonElement
from ableton.v2.control_surface.input_control_element import MIDI_PB_TYPE, MIDI_CC_TYPE
from ableton.v2.base import listens

# --- SETTINGS ---
SENSITIVITY = 1.0
# ----------------

# Protocol Definition
SYSEX_START = (240, 0, 127, 16)
SYSEX_END = (247,)
CMD_TRACK = 1
CMD_PARAM = 2
CMD_VALUE = 3
CMD_COLOR = 4
CMD_SYNC  = 5
CMD_LED   = 6
CMD_FAV_NAME = 7  
CMD_FAV_COLOR = 8  # <-- NEW: Command for favourite button colors

class Grid_VSN1(ControlSurface):
    def __init__(self, c_instance):
        super().__init__(c_instance)
        with self.component_guard():
            # 1. Setup the main encoder
            self._encoder = EncoderElement(
                MIDI_PB_TYPE, 15, 0, Live.MidiMap.MapMode.absolute
            )
            self._on_encoder_moved.subject = self._encoder
            
            # 2. Setup the Encoder Push Button
            self._encoder_btn = ButtonElement(True, MIDI_CC_TYPE, 15, 10)
            self._on_encoder_btn_pressed.subject = self._encoder_btn

            # 3. Setup Favourites System
            self._favourites = [None] * 8
            self._fav_press_times = {}
            self._fav_buttons = []
            
            for i in range(8):
                btn = ButtonElement(True, MIDI_CC_TYPE, 15, 32 + i)
                self._fav_buttons.append(btn)
                btn.add_value_listener(lambda val, idx=i: self._handle_fav_button(val, idx))

            # 4. Setup Parameter tracking
            self._active_parameter = None
            self._on_selected_parameter_changed.subject = self.song.view
            self._on_selected_parameter_changed()
            
            # 5. DEBOUNCE TIMER
            self._last_encoder_time = 0.0
            
            self.show_message("Last Touched: Split Update Active")
            
            # 4. Setup Transport System (CCs 40-47)
            self._transport_buttons = []
            for i in range(8):
                # Change 40 + i if your transport CCs are different
                btn = ButtonElement(True, MIDI_CC_TYPE, 15, 40 + i)
                self._transport_buttons.append(btn)
                btn.add_value_listener(lambda val, idx=i: self._handle_transport_button(val, idx))

            # ... (Parameter tracking and Debounce timer stay here) ...
            
            # 7. Listeners to sync Transport LEDs when mouse is used in Ableton
            self.song.add_is_playing_listener(self._sync_transport_leds)
            self.song.add_record_mode_listener(self._sync_transport_leds)
            self.song.add_loop_listener(self._sync_transport_leds)

            # NEW: Listen for the controller signaling it switched back to the Favourites page
            # (Change CC 48 to match your hardware's page-switch output)
            self._fav_refresh_btn = ButtonElement(True, MIDI_CC_TYPE, 15, 48)
            self._fav_refresh_btn.add_value_listener(self._on_refresh_favourites_requested)

            self._transport_refresh_btn = ButtonElement(True, MIDI_CC_TYPE, 15, 49)
            self._transport_refresh_btn.add_value_listener(self._on_refresh_transport_requested)

            



    # --- NATIVE FAVOURITES HANDLER ---
    def _handle_fav_button(self, value, index):
        if value > 0:
            self._fav_press_times[index] = time.time()
        else:
            press_time = self._fav_press_times.get(index, 0)
            if time.time() - press_time >= 1.0: 
                self._save_favourite(index)
            else:                               
                self._recall_favourite(index)

    def _save_favourite(self, index):
        if self._active_parameter:
            self._favourites[index] = self._active_parameter
            #self._update_favourite_screen(index)
            self._update_favourite_color(index)
            self.show_message(f"SAVED: {self._active_parameter.name} to Slot {index + 1}")

    def _recall_favourite(self, index):
        target_param = self._favourites[index]
        if target_param != None:
            try:
                self._active_parameter = target_param
                self._on_val_changed.subject = self._active_parameter
                self._send_full_refresh()
                self.show_message(f"RECALLED: {target_param.name}")
            except Exception:
                self._favourites[index] = None
                #self._update_favourite_screen(index)
                self._update_favourite_color(index)
                self.show_message(f"Slot {index + 1} parameter lost.")
        else:
            self.show_message(f"Slot {index + 1} is empty!")

    def _update_favourite_screen(self, index):
        param = self._favourites[index]
        name = param.name if param else "Empty"
        ascii_bytes = [ord(c) for c in name[:10]] 
        msg = SYSEX_START + (CMD_FAV_NAME, index) + tuple(ascii_bytes) + SYSEX_END
        self._send_midi(msg)

    def _update_favourite_color(self, index):
            param = self._favourites[index]
            r, g, b = 0, 0, 0 # Default to Black/Off if the slot is empty

            if param:
                try:
                    # Climb up the tree to find the track color
                    target = param.canonical_parent
                    while target and not hasattr(target, 'color'):
                        target = getattr(target, 'canonical_parent', None)
                    
                    if target:
                        c = target.color
                        r = (c >> 17) & 127
                        g = (c >> 9) & 127
                        b = (c >> 1) & 127
                except Exception:
                    pass 
                    
            msg = SYSEX_START + (CMD_FAV_COLOR, index, r, g, b) + SYSEX_END
            self._send_midi(msg)

    # --- TRANSPORT HANDLER ---

    def _on_refresh_transport_requested(self, value):
        """Triggered when the controller switches to the Transport page"""
        if value > 0: # Trigger on press
            self._sync_transport_leds()

    def _handle_transport_button(self, value, index):
        if value > 0: # Execute on button down
            try:
                if index == 0:
                    self.song.start_playing()               
                elif index == 1:
                    self.song.stop_playing()
                elif index == 2:
                    self.song.record_mode = not self.song.record_mode
                elif index == 3:
                    self.song.loop = not self.song.loop
                elif index == 4:
                    self.song.create_audio_track(-1)
                elif index == 5:
                    self.song.create_midi_track(-1)
                elif index == 6:
                    if self.song.can_undo: self.song.undo()
                elif index == 7:
                    if self.song.can_redo: self.song.redo()
            except Exception:
                pass # Catch errors for trial versions or empty undo queues

    def _sync_transport_leds(self):
        """Sends CCs back to the controller to update Play, Record, and Loop LEDs"""
        try:
            # Play (Index 0 / CC 40)
            play_val = 127 if self.song.is_playing else 0
            #self._transport_buttons[0].send_value(play_val)
            self._send_midi((191,40,play_val))
            
            # Stop (Index 1 / CC 41)
            stop_val = 127 if not self.song.is_playing else 0
            #self._transport_buttons[1].send_value(stop_val)
            self._send_midi((191,41,stop_val))

            # Record (Index 2 / CC 42)
            rec_val = 127 if self.song.record_mode else 0
            #self._transport_buttons[2].send_value(rec_val)
            self._send_midi((191,42,rec_val))
            
            # Loop (Index 3 / CC 43)
            loop_val = 127 if self.song.loop else 0
            #self._transport_buttons[3].send_value(loop_val)
            self._send_midi((191,43,loop_val))
        except Exception:
            pass

    def _on_refresh_favourites_requested(self, value):
        """Triggered when the controller tells Ableton it switched back to the Favourites page"""
        if value > 0: # Trigger on press
            self._send_all_favourites_metadata()

    def _send_all_favourites_metadata(self):
        """Loops through all 8 slots and blasts names and colors back to the hardware"""
        for i in range(8):
            #self._update_favourite_screen(i)
            self._update_favourite_color(i)

    # --- ENCODER BUTTON LISTENER ---
    @listens('value')
    def _on_encoder_btn_pressed(self, value):
        if value > 0 and self._active_parameter:
            self._active_parameter.value = self._active_parameter.default_value

    # --- PARAMETER LISTENERS ---
    @listens('selected_parameter')
    def _on_selected_parameter_changed(self):
        self._active_parameter = self.song.view.selected_parameter
        self._on_val_changed.subject = self._active_parameter
        if self._active_parameter:
            self._send_full_refresh()

    @listens('value')
    def _on_val_changed(self):
        if self._active_parameter:
            # 1. ALWAYS update the text string
            self._send_text(CMD_VALUE, self._get_parameter_value_string())
            
            # 2. ALWAYS update the LED ring
            self._send_14bit_float(CMD_LED)
            
            # 3. ONLY send the CMD_SYNC math if 150ms has passed since encoder move
            time_since_last_move = time.time() - self._last_encoder_time
            if time_since_last_move > 0.15:
                self._send_14bit_float(CMD_SYNC)

    @listens('value')
    def _on_encoder_moved(self, value):
        if self._active_parameter:
            self._last_encoder_time = time.time()
            p = self._active_parameter
            try:
                norm_val = (value / 16383.0) * (p.max - p.min) + p.min
                p.value = max(p.min, min(p.max, norm_val))
            except Exception:
                pass

    # --- HELPER FUNCTIONS ---
    def _get_track_name(self):
        if not self._active_parameter: 
            return "Global"
            
        # 1. Grab the device/plugin (the immediate parent of the parameter)
        parent = self._active_parameter.canonical_parent
        
        # Most devices have a 'name' attribute. The Mixer doesn't, so we default to "Mixer"
        device_name = getattr(parent, 'name', 'Mixer')
        
        # 2. Traverse up the hierarchy to find the Track
        target = parent
        while target and not isinstance(target, Live.Track.Track):
            target = getattr(target, 'canonical_parent', None)
            
        track_name = target.name if target else "Global"
        
        # 3. Combine them into a single string for your controller's screen
        return f"{track_name}:{device_name}"

    def _get_parameter_value_string(self):
        p = self._active_parameter
        try: return str(p.str_for_value(p.value))
        except:
            try: return str(p.str_for_value())
            except: return "{:.2f}".format(p.value)

    # --- SYSEX SENDING FUNCTIONS ---
    def _send_full_refresh(self):
        if not self._active_parameter: return
        self._send_text(CMD_TRACK, self._get_track_name())
        self._send_text(CMD_PARAM, self._active_parameter.name)
        self._send_text(CMD_VALUE, self._get_parameter_value_string())
        self._send_color()
        self._send_14bit_float(CMD_SYNC)

    def _send_text(self, cmd, text):
        ascii_bytes = [ord(c) for c in text[:32]]
        msg = SYSEX_START + (cmd,) + tuple(ascii_bytes) + SYSEX_END
        self._send_midi(msg)

    def _send_14bit_float(self, cmd):
        p = self._active_parameter
        val_range = p.max - p.min
        if val_range > 0:
            full_val = int(round(((p.value - p.min) / val_range) * 16383))
            msb = (full_val >> 7) & 0x7F
            lsb = full_val & 0x7F
            self._send_midi(SYSEX_START + (cmd, msb, lsb) + SYSEX_END)

    def _send_color(self):
        try:
            target = self._active_parameter.canonical_parent
            while target and not hasattr(target, 'color'):
                target = target.canonical_parent
            if target:
                c = target.color
                self._send_midi(SYSEX_START + (CMD_COLOR, (c>>17)&127, (c>>9)&127, (c>>1)&127) + SYSEX_END)
        except: pass